import { useState, useEffect } from "react";
import {
  Plus,
  Clock,
  CheckCircle,
  XCircle,
  Trash2,
} from "lucide-react";

export default function Leave() {
  /* ================= STATE ================= */

  const [leaves, setLeaves] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const EMPLOYEE_ID = 1; // demo logged-in employee

  const [formData, setFormData] = useState({
    type: "Sick Leave",
    from: "",
    to: "",
    reason: "",
  });

  /* ================= LOAD FROM STORAGE ================= */

  useEffect(() => {
    const stored =
      JSON.parse(localStorage.getItem("leaveRequests")) || [];
    setLeaves(stored);
  }, []);

  /* ================= APPLY LEAVE ================= */

  const handleApplyLeave = () => {
    const newLeave = {
      id: Date.now(),
      employeeId: EMPLOYEE_ID,
      employeeName: "Ayan Hashmi",
      type: formData.type,
      from: formData.from,
      to: formData.to,
      reason: formData.reason,
      status: "Pending",
      message: "", // admin will update
    };

    const updated = [...leaves, newLeave];
    setLeaves(updated);
    localStorage.setItem("leaveRequests", JSON.stringify(updated));

    setShowModal(false);
    setFormData({
      type: "Sick Leave",
      from: "",
      to: "",
      reason: "",
    });
  };

  /* ================= DELETE MESSAGE (EMPLOYEE CHOICE) ================= */

  const handleDelete = (id) => {
    const updated = leaves.filter((l) => l.id !== id);
    setLeaves(updated);
    localStorage.setItem("leaveRequests", JSON.stringify(updated));
  };

  /* ================= FILTER ================= */

  const myLeaves = leaves.filter(
    (l) => l.employeeId === EMPLOYEE_ID
  );

  return (
    <div className="p-6 space-y-6">

      {/* HEADER */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">My Leave Requests</h1>

        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg"
        >
          <Plus size={16} /> Apply Leave
        </button>
      </div>

      {/* LEAVE LIST */}
      <div className="space-y-4">
        {myLeaves.length === 0 && (
          <p className="text-gray-500 text-sm">
            No leave requests found
          </p>
        )}

        {myLeaves.map((l) => (
          <div
            key={l.id}
            className="bg-white rounded-xl shadow p-4"
          >
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">{l.type}</p>
                <p className="text-sm text-gray-500">
                  {l.from} → {l.to}
                </p>
              </div>

              {/* STATUS */}
              <div>
                {l.status === "Pending" && (
                  <span className="flex items-center gap-1 text-yellow-600 text-xs">
                    <Clock size={14} /> Pending
                  </span>
                )}
                {l.status === "Approved" && (
                  <span className="flex items-center gap-1 text-green-600 text-xs">
                    <CheckCircle size={14} /> Approved
                  </span>
                )}
                {l.status === "Rejected" && (
                  <span className="flex items-center gap-1 text-red-600 text-xs">
                    <XCircle size={14} /> Rejected
                  </span>
                )}
              </div>
            </div>

            {/* ================= ADMIN MESSAGE ================= */}
            {l.message && (
              <div
                className={`mt-3 text-sm rounded-lg p-3 ${
                  l.status === "Approved"
                    ? "bg-green-50 text-green-700"
                    : "bg-red-50 text-red-700"
                }`}
              >
                {l.message}
              </div>
            )}

            {/* DELETE BUTTON */}
            {(l.status === "Approved" || l.status === "Rejected") && (
              <div className="mt-3 text-right">
                <button
                  onClick={() => handleDelete(l.id)}
                  className="text-red-500 text-xs flex items-center gap-1 ml-auto"
                >
                  <Trash2 size={14} /> Delete Message
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ================= APPLY LEAVE MODAL ================= */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h2 className="text-lg font-semibold mb-4">
              Apply Leave
            </h2>

            <div className="space-y-3 text-sm">
              <div>
                <label>Leave Type</label>
                <select
                  className="w-full border px-3 py-2 rounded"
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      type: e.target.value,
                    })
                  }
                >
                  <option>Sick Leave</option>
                  <option>Casual Leave</option>
                  <option>Paid Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label>From</label>
                  <input
                    type="date"
                    className="w-full border px-3 py-2 rounded"
                    value={formData.from}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        from: e.target.value,
                      })
                    }
                  />
                </div>

                <div>
                  <label>To</label>
                  <input
                    type="date"
                    className="w-full border px-3 py-2 rounded"
                    value={formData.to}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        to: e.target.value,
                      })
                    }
                  />
                </div>
              </div>

              <div>
                <label>Reason</label>
                <textarea
                  rows="3"
                  className="w-full border px-3 py-2 rounded"
                  value={formData.reason}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      reason: e.target.value,
                    })
                  }
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 mt-6">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>

              <button
                onClick={handleApplyLeave}
                className="px-4 py-2 bg-blue-600 text-white rounded"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
