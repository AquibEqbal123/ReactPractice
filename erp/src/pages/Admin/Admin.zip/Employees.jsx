import { useState } from "react";
import {
  FaPlus,
  FaEye,
  FaEdit,
  FaTrash,
  FaTimes,
} from "react-icons/fa";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

import { useNavigate } from "react-router-dom";

export default function Employees() {
  /* ================= DATA ================= */

  const [employees, setEmployees] = useState([
    {
      id: 1,
      name: "Ayan Hashmi",
      role: "Frontend Developer",
      department: "IT",
      status: "Active",
    },
    {
      id: 2,
      name: "Rahul Sharma",
      role: "Backend Developer",
      department: "IT",
      status: "Inactive",
    },
    {
      id: 3,
      name: "Sneha Verma",
      role: "HR Manager",
      department: "HR",
      status: "Active",
    },
  ]);

  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [mode, setMode] = useState(""); // add | edit
  const [current, setCurrent] = useState(null);

  // 🔹 DELETE MODAL STATE (NEW)
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  const emptyForm = {
    name: "",
    role: "",
    department: "",
    status: "Active",
  };

  const [formData, setFormData] = useState(emptyForm);

  /* ================= PAGINATION ================= */

  const [page, setPage] = useState(1);
  const itemsPerPage = 2;

  /* ================= GRAPH FILTERS ================= */

  const [graphDepartment, setGraphDepartment] = useState("All");
  const [graphStatus, setGraphStatus] = useState("All");

  const graphFilteredEmployees = employees.filter((e) => {
    if (graphDepartment !== "All" && e.department !== graphDepartment)
      return false;
    if (graphStatus !== "All" && e.status !== graphStatus)
      return false;
    return true;
  });

  /* ================= TABLE FILTER ================= */

  const filteredEmployees = employees.filter((emp) =>
    emp.name.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage);

  const paginatedEmployees = filteredEmployees.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  /* ================= GRAPH DATA ================= */

  const departmentData = [
    {
      name: "IT",
      value: graphFilteredEmployees.filter(
        (e) => e.department === "IT"
      ).length,
    },
    {
      name: "HR",
      value: graphFilteredEmployees.filter(
        (e) => e.department === "HR"
      ).length,
    },
    {
      name: "Other",
      value: graphFilteredEmployees.filter(
        (e) => !["IT", "HR"].includes(e.department)
      ).length,
    },
  ];

  const statusData = [
    {
      name: "Active",
      value: graphFilteredEmployees.filter(
        (e) => e.status === "Active"
      ).length,
    },
    {
      name: "Inactive",
      value: graphFilteredEmployees.filter(
        (e) => e.status === "Inactive"
      ).length,
    },
  ];

  const COLORS = ["#22c55e", "#ef4444", "#6366f1"];

  /* ================= ACTIONS ================= */

  const openAdd = () => {
    setMode("add");
    setFormData(emptyForm);
    setShowModal(true);
  };

  const openEdit = (emp) => {
    setMode("edit");
    setCurrent(emp);
    setFormData(emp);
    setShowModal(true);
  };

  // 🔹 OPEN DELETE MODAL (REPLACED confirm)
  const handleDelete = (emp) => {
    setCurrent(emp);
    setShowDeleteModal(true);
  };

  // 🔹 CONFIRM DELETE
  const confirmDelete = () => {
    setEmployees(employees.filter((e) => e.id !== current.id));
    setShowDeleteModal(false);
  };

  const handleSave = (e) => {
    e.preventDefault();

    if (mode === "add") {
      setEmployees([...employees, { id: Date.now(), ...formData }]);
    }

    if (mode === "edit") {
      setEmployees(
        employees.map((e) =>
          e.id === current.id ? { ...current, ...formData } : e
        )
      );
    }

    setShowModal(false);
  };

  return (
    <div className="p-6 space-y-8">

      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-semibold">Employees</h1>
        <p className="text-sm text-gray-500">
          Manage employees and analytics
        </p>
      </div>

      {/* ===== GRAPH FILTERS ===== */}
      <div className="bg-white rounded-xl shadow p-4 flex gap-4">
        <select
          value={graphDepartment}
          onChange={(e) => setGraphDepartment(e.target.value)}
          className="border px-3 py-2 rounded"
        >
          <option value="All">All Departments</option>
          <option value="IT">IT</option>
          <option value="HR">HR</option>
          <option value="Other">Other</option>
        </select>

        <select
          value={graphStatus}
          onChange={(e) => setGraphStatus(e.target.value)}
          className="border px-3 py-2 rounded"
        >
          <option value="All">All Status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      {/* ===== GRAPHS ===== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="text-sm font-semibold mb-4">
            Employees by Department
          </h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={departmentData}>
              <XAxis dataKey="name" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="text-sm font-semibold mb-4">
            Active vs Inactive
          </h2>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={statusData} dataKey="value" cx="50%" cy="50%" outerRadius={90} label>
                {statusData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ===== SEARCH + ADD ===== */}
      <div className="flex justify-between gap-4">
        <input
          type="text"
          placeholder="Search employee..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          className="w-1/3 border px-4 py-2 rounded-lg"
        />

        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg"
        >
          <FaPlus /> Add Employee
        </button>
      </div>

      {/* ===== TABLE ===== */}
      <div className="bg-white rounded-xl shadow">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Role</th>
              <th className="px-4 py-3 text-left">Department</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {paginatedEmployees.map((emp) => (
              <tr key={emp.id} className="border-t">
                <td className="px-4 py-3 font-medium">{emp.name}</td>
                <td className="px-4 py-3">{emp.role}</td>
                <td className="px-4 py-3">{emp.department}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded text-xs ${
                    emp.status === "Active"
                      ? "bg-green-100 text-green-600"
                      : "bg-red-100 text-red-600"
                  }`}>
                    {emp.status}
                  </span>
                </td>
                <td className="px-4 py-3 flex justify-center gap-2">
                  <button
                    onClick={() => navigate(`/employee/dashboard/${emp.id}`)}
                    className="bg-blue-500 text-white p-2 rounded"
                  >
                    <FaEye />
                  </button>
                  <button
                    onClick={() => openEdit(emp)}
                    className="bg-indigo-500 text-white p-2 rounded"
                  >
                    <FaEdit />
                  </button>
                  <button
                    onClick={() => handleDelete(emp)}
                    className="bg-red-500 text-white p-2 rounded"
                  >
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* PAGINATION */}
        <div className="flex justify-between items-center p-4">
          <button disabled={page === 1} onClick={() => setPage(page - 1)}
            className="px-3 py-1 bg-gray-200 rounded">
            Previous
          </button>

          <span>Page {page} of {totalPages}</span>

          <button disabled={page === totalPages} onClick={() => setPage(page + 1)}
            className="px-3 py-1 bg-gray-200 rounded">
            Next
          </button>
        </div>
      </div>

      {/* ===== ADD / EDIT MODAL ===== */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
          <div className="bg-white w-full max-w-md rounded-xl p-6 relative">
            <button onClick={() => setShowModal(false)} className="absolute top-4 right-4">
              <FaTimes />
            </button>

            <h2 className="text-lg font-semibold mb-4 capitalize">
              {mode} Employee
            </h2>

            <form onSubmit={handleSave} className="space-y-3">
              <input className="w-full border px-3 py-2 rounded" placeholder="Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
              <input className="w-full border px-3 py-2 rounded" placeholder="Role"
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              />
              <input className="w-full border px-3 py-2 rounded" placeholder="Department"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              />
              <select className="w-full border px-3 py-2 rounded"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option>Active</option>
                <option>Inactive</option>
              </select>

              <button className="w-full bg-purple-600 text-white py-2 rounded-lg">
                Save
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ===== DELETE CONFIRM MODAL ===== */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-full max-w-sm rounded-xl p-6 text-center relative">
            <button
              onClick={() => setShowDeleteModal(false)}
              className="absolute top-4 right-4"
            >
              <FaTimes />
            </button>

            <h2 className="text-lg font-semibold mb-2">Are you sure?</h2>
            <p className="text-sm text-gray-600 mb-6">
              Do you really want to delete <b>{current?.name}</b>?
            </p>

            <div className="flex justify-center gap-4">
              <button
                onClick={confirmDelete}
                className="bg-red-600 text-white px-4 py-2 rounded"
              >
                Yes, Delete
              </button>
              <button
                onClick={() => setShowDeleteModal(false)}
                className="bg-gray-200 px-4 py-2 rounded"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
