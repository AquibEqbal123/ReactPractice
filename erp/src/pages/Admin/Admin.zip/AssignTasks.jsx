import { useEffect, useState } from "react";
import {
  FaPlus,
  FaTasks,
  FaCalendarAlt,
  FaUserTie,
  FaTimes,
} from "react-icons/fa";

export default function AssignTasks() {
  /* ================= STATE ================= */

  const [tasks, setTasks] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const emptyTask = {
    employeeName: "",
    title: "",
    description: "",
    startDate: "",
    endDate: "",
    priority: "Medium",
    status: "Assigned",
  };

  const [formData, setFormData] = useState(emptyTask);

  /* ================= LOAD FROM STORAGE ================= */

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("assignedTasks")) || [];
    setTasks(stored);
  }, []);

  const updateStorage = (data) => {
    localStorage.setItem("assignedTasks", JSON.stringify(data));
  };

  /* ================= ACTIONS ================= */

  const openAdd = () => {
    setFormData(emptyTask);
    setShowModal(true);
  };

  const handleSave = (e) => {
    e.preventDefault();

    const updated = [
      ...tasks,
      {
        id: Date.now(),
        ...formData,
      },
    ];

    setTasks(updated);
    updateStorage(updated);
    setShowModal(false);
  };

  return (
    <div className="p-6 space-y-6">

      {/* ================= HEADER ================= */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <FaTasks /> Assign Tasks
          </h1>
          <p className="text-sm text-gray-500">
            Assign work to employees with deadlines and priority
          </p>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg"
        >
          <FaPlus /> Assign Task
        </button>
      </div>

      {/* ================= TASK TABLE ================= */}
      <div className="bg-white rounded-xl shadow overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 text-left">Employee</th>
              <th className="text-left">Task</th>
              <th className="text-left">Duration</th>
              <th className="text-left">Priority</th>
              <th className="text-center">Status</th>
            </tr>
          </thead>

          <tbody>
            {tasks.length === 0 ? (
              <tr>
                <td colSpan="5" className="p-4 text-center text-gray-500">
                  No tasks assigned yet
                </td>
              </tr>
            ) : (
              tasks.map((task) => (
                <tr key={task.id} className="border-t">
                  <td className="p-3 font-medium flex items-center gap-2">
                    <FaUserTie />
                    {task.employeeName}
                  </td>
                  <td>
                    <p className="font-medium">{task.title}</p>
                    <p className="text-xs text-gray-500">
                      {task.description}
                    </p>
                  </td>
                  <td>
                    <div className="text-xs flex items-center gap-1">
                      <FaCalendarAlt />
                      {task.startDate} → {task.endDate}
                    </div>
                  </td>
                  <td>
                    <span
                      className={`px-2 py-1 rounded text-xs ${
                        task.priority === "High"
                          ? "bg-red-100 text-red-600"
                          : task.priority === "Medium"
                          ? "bg-yellow-100 text-yellow-600"
                          : "bg-green-100 text-green-600"
                      }`}
                    >
                      {task.priority}
                    </span>
                  </td>
                  <td className="text-center">
                    <span className="bg-blue-100 text-blue-600 px-2 py-1 rounded text-xs">
                      {task.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ================= MODAL ================= */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white w-full max-w-lg rounded-xl p-6 relative">

            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 text-gray-500"
            >
              <FaTimes />
            </button>

            <h2 className="text-lg font-semibold mb-4">
              Assign New Task
            </h2>

            <form onSubmit={handleSave} className="space-y-4 text-sm">

              <input
                placeholder="Employee Name"
                className="w-full border px-3 py-2 rounded"
                value={formData.employeeName}
                onChange={(e) =>
                  setFormData({ ...formData, employeeName: e.target.value })
                }
                required
              />

              <input
                placeholder="Task Title"
                className="w-full border px-3 py-2 rounded"
                value={formData.title}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
                required
              />

              <textarea
                placeholder="Task Description (what needs to be done)"
                rows={3}
                className="w-full border px-3 py-2 rounded"
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                required
              />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-gray-600">Start Date</label>
                  <input
                    type="date"
                    className="w-full border px-3 py-2 rounded"
                    value={formData.startDate}
                    onChange={(e) =>
                      setFormData({ ...formData, startDate: e.target.value })
                    }
                    required
                  />
                </div>

                <div>
                  <label className="text-gray-600">End Date</label>
                  <input
                    type="date"
                    className="w-full border px-3 py-2 rounded"
                    value={formData.endDate}
                    onChange={(e) =>
                      setFormData({ ...formData, endDate: e.target.value })
                    }
                    required
                  />
                </div>
              </div>

              <select
                className="w-full border px-3 py-2 rounded"
                value={formData.priority}
                onChange={(e) =>
                  setFormData({ ...formData, priority: e.target.value })
                }
              >
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
              </select>

              <button className="w-full bg-indigo-600 text-white py-2 rounded-lg">
                Assign Task
              </button>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
