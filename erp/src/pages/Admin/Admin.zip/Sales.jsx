import { useState } from "react";
import {
  FaPlus,
  FaEye,
  FaEdit,
  FaTrash,
  FaTimes,
} from "react-icons/fa";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

export default function Sales() {
  /* ---------------- DATA ---------------- */

  const [sales, setSales] = useState([
    {
      id: 1,
      name: "Winter Wonderland Sale ❄️",
      start: "2025-12-06",
      end: "2025-12-30",
      status: "Live",
    },
    {
      id: 2,
      name: "Diwali Bumper Offer",
      start: "2025-10-18",
      end: "2025-10-20",
      status: "Ended",
    },
  ]);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All"); // table filter

  const [showModal, setShowModal] = useState(false);
  const [mode, setMode] = useState(""); // add | view | edit | delete
  const [current, setCurrent] = useState(null);

  const [formData, setFormData] = useState({
    name: "",
    start: "",
    end: "",
    status: "Live",
  });

  /* ---------------- PAGINATION ---------------- */

  const [page, setPage] = useState(1);
  const itemsPerPage = 2;

  /* ---------------- GRAPH FILTERS (NEW) ---------------- */

  const [graphStatus, setGraphStatus] = useState("All");

  const graphFilteredSales = sales.filter((s) => {
    if (graphStatus !== "All" && s.status !== graphStatus) return false;
    return true;
  });

  /* ---------------- TABLE FILTER ---------------- */

  const filteredSales = sales.filter((item) => {
    if (
      !item.name.toLowerCase().includes(search.toLowerCase())
    )
      return false;

    if (statusFilter !== "All" && item.status !== statusFilter)
      return false;

    return true;
  });

  const totalPages = Math.ceil(filteredSales.length / itemsPerPage);

  const paginatedSales = filteredSales.slice(
    (page - 1) * itemsPerPage,
    page * itemsPerPage
  );

  /* ---------------- GRAPH DATA ---------------- */

  const statusData = [
    {
      name: "Live",
      value: graphFilteredSales.filter(
        (s) => s.status === "Live"
      ).length,
    },
    {
      name: "Ended",
      value: graphFilteredSales.filter(
        (s) => s.status === "Ended"
      ).length,
    },
  ];

  const COLORS = ["#22c55e", "#9ca3af"];

  /* ---------------- ACTIONS ---------------- */

  const openAdd = () => {
    setMode("add");
    setFormData({ name: "", start: "", end: "", status: "Live" });
    setShowModal(true);
  };

  const openView = (item) => {
    setMode("view");
    setCurrent(item);
    setShowModal(true);
  };

  const openEdit = (item) => {
    setMode("edit");
    setCurrent(item);
    setFormData(item);
    setShowModal(true);
  };

  const openDelete = (item) => {
    setMode("delete");
    setCurrent(item);
    setShowModal(true);
  };

  const handleDelete = () => {
    setSales(sales.filter((s) => s.id !== current.id));
    setShowModal(false);
  };

  const handleSave = (e) => {
    e.preventDefault();

    if (mode === "add") {
      setSales([...sales, { id: Date.now(), ...formData }]);
    }

    if (mode === "edit") {
      setSales(
        sales.map((s) =>
          s.id === current.id ? { ...current, ...formData } : s
        )
      );
    }

    setShowModal(false);
  };

  return (
    <div className="p-6 space-y-8">

      {/* HEADER */}
      <div>
        <h1 className="text-2xl font-semibold">Sales</h1>
        <p className="text-sm text-gray-500">
          Sales performance and transaction management
        </p>
      </div>

      {/* PAGE TITLE */}
      <h1 className="text-2xl font-semibold">Promotional Banners</h1>

      {/* ===== GRAPH FILTER ===== */}
      <div className="bg-white p-4 rounded-xl shadow flex gap-4">
        <select
          value={graphStatus}
          onChange={(e) => setGraphStatus(e.target.value)}
          className="border px-3 py-2 rounded"
        >
          <option value="All">All Status</option>
          <option value="Live">Live</option>
          <option value="Ended">Ended</option>
        </select>
      </div>

      {/* ====== GRAPHS ====== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="text-sm font-semibold mb-4">
            Banner Status Overview
          </h2>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={statusData}>
              <XAxis dataKey="name" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#6366f1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl shadow p-5">
          <h2 className="text-sm font-semibold mb-4">
            Live vs Ended
          </h2>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={statusData}
                dataKey="value"
                cx="50%"
                cy="50%"
                outerRadius={90}
                label
              >
                {statusData.map((_, i) => (
                  <Cell key={i} fill={COLORS[i]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ===== TABLE FILTER + ADD ===== */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <input
          type="text"
          placeholder="Search banners..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          className="w-full md:w-1/3 border px-4 py-2 rounded-lg"
        />

        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="border px-3 py-2 rounded"
        >
          <option value="All">All Status</option>
          <option value="Live">Live</option>
          <option value="Ended">Ended</option>
        </select>

        <button
          onClick={openAdd}
          className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg"
        >
          <FaPlus /> Add Banner
        </button>
      </div>

      {/* ===== TABLE ===== */}
      <div className="bg-white rounded-xl shadow">
        <table className="w-full text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-3 text-left">Banner Name</th>
              <th className="text-left">Start Date</th>
              <th className="text-left">End Date</th>
              <th className="text-left">Status</th>
              <th className="text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {paginatedSales.map((item) => (
              <tr key={item.id} className="border-t">
                <td className="px-4 py-3 font-medium">{item.name}</td>
                <td>{item.start}</td>
                <td>{item.end}</td>
                <td>
                  <span
                    className={`px-2 py-1 rounded text-xs ${
                      item.status === "Live"
                        ? "bg-green-100 text-green-600"
                        : "bg-gray-200 text-gray-600"
                    }`}
                  >
                    {item.status}
                  </span>
                </td>
                <td className="px-4 py-3 flex justify-center gap-2">
                  <button
                    onClick={() => openView(item)}
                    className="bg-blue-500 text-white p-2 rounded"
                  >
                    <FaEye />
                  </button>
                  <button
                    onClick={() => openEdit(item)}
                    className="bg-indigo-500 text-white p-2 rounded"
                  >
                    <FaEdit />
                  </button>
                  <button
                    onClick={() => openDelete(item)}
                    className="bg-red-500 text-white p-2 rounded"
                  >
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* PAGINATION */}
        <div className="flex justify-between items-center p-4">
          <button
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Previous
          </button>

          <span className="text-sm">
            Page {page} of {totalPages}
          </span>

          <button
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
            className="px-3 py-1 bg-gray-200 rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>

      {/* ===== MODAL ===== */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
          <div className="bg-white w-full max-w-md rounded-xl p-6 relative">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4"
            >
              <FaTimes />
            </button>

            <h2 className="text-lg font-semibold mb-4 capitalize">
              {mode} Banner
            </h2>

            {mode === "delete" ? (
              <div className="text-center space-y-4">
                <p className="text-sm text-gray-600">
                  Are you sure you want to delete <b>{current.name}</b>?
                </p>
                <div className="flex justify-center gap-4">
                  <button
                    onClick={handleDelete}
                    className="bg-red-600 text-white px-4 py-2 rounded"
                  >
                    Yes, Delete
                  </button>
                  <button
                    onClick={() => setShowModal(false)}
                    className="bg-gray-200 px-4 py-2 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : mode === "view" ? (
              <div className="space-y-2 text-sm">
                <p><b>Name:</b> {current.name}</p>
                <p><b>Start:</b> {current.start}</p>
                <p><b>End:</b> {current.end}</p>
                <p><b>Status:</b> {current.status}</p>
              </div>
            ) : (
              <form onSubmit={handleSave} className="space-y-3">
                <input
                  className="w-full border px-3 py-2 rounded"
                  placeholder="Banner Name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                />
                <input
                  type="date"
                  className="w-full border px-3 py-2 rounded"
                  value={formData.start}
                  onChange={(e) =>
                    setFormData({ ...formData, start: e.target.value })
                  }
                  required
                />
                <input
                  type="date"
                  className="w-full border px-3 py-2 rounded"
                  value={formData.end}
                  onChange={(e) =>
                    setFormData({ ...formData, end: e.target.value })
                  }
                  required
                />
                <select
                  className="w-full border px-3 py-2 rounded"
                  value={formData.status}
                  onChange={(e) =>
                    setFormData({ ...formData, status: e.target.value })
                  }
                >
                  <option>Live</option>
                  <option>Ended</option>
                </select>

                <button className="w-full bg-green-600 text-white py-2 rounded-lg">
                  Save
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
