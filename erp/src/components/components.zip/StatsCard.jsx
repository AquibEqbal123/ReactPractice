import { FaUsers, FaBoxes, FaShoppingCart, FaChartLine } from "react-icons/fa";

const cards = [
  {
    title: "Employees",
    value: "120",
    icon: <FaUsers />,
    color: "bg-blue-500",
  },
  {
    title: "Inventory Items",
    value: "1,540",
    icon: <FaBoxes />,
    color: "bg-green-500",
  },
  {
    title: "Total Sales",
    value: "₹3.2L",
    icon: <FaShoppingCart />,
    color: "bg-purple-500",
  },
  {
    title: "Growth",
    value: "+18%",
    icon: <FaChartLine />,
    color: "bg-pink-500",
  },
];

export default function StatsCard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
      {cards.map((c, i) => (
        <div
          key={i}
          className="bg-white rounded-xl shadow p-5 flex items-center gap-4"
        >
          <div
            className={`${c.color} text-white p-3 rounded-lg text-xl`}
          >
            {c.icon}
          </div>
          <div>
            <p className="text-sm text-gray-500">{c.title}</p>
            <h3 className="text-xl font-semibold">{c.value}</h3>
          </div>
        </div>
      ))}
    </div>
  );
}
