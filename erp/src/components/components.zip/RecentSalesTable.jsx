import { useState, useMemo } from "react";
import {
  FaEye,
  FaEdit,
  FaTrash,
  FaPlus,
  FaTimes,
  FaChevronLeft,
  FaChevronRight,
  FaSearch,
} from "react-icons/fa";

export default function RecentSalesTable() {
  /* ================= STATE ================= */

  const [sales, setSales] = useState([
    {
      id: 1,
      customer: "Ayan Hashmi",
      product: "Laptop",
      amount: "₹55,000",
      status: "Completed",
    },
    {
      id: 2,
      customer: "Rahul Sharma",
      product: "Office Chair",
      amount: "₹6,500",
      status: "Pending",
    },
    {
      id: 3,
      customer: "Neha Verma",
      product: "Monitor",
      amount: "₹12,000",
      status: "Completed",
    },
    {
      id: 4,
      customer: "Imran Khan",
      product: "Keyboard",
      amount: "₹2,000",
      status: "Pending",
    },
  ]);

  const emptyForm = {
    customer: "",
    product: "",
    amount: "",
    status: "Pending",
  };

  const [formData, setFormData] = useState(emptyForm);
  const [selectedItem, setSelectedItem] = useState(null);

  const [showAdd, setShowAdd] = useState(false);
  const [showView, setShowView] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  /* ================= SEARCH & FILTER ================= */

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [productFilter, setProductFilter] = useState("");

  const filteredSales = useMemo(() => {
    return sales.filter((item) => {
      const text =
        `${item.customer} ${item.product} ${item.amount} ${item.status}`.toLowerCase();

      if (search && !text.includes(search.toLowerCase())) return false;
      if (statusFilter && item.status !== statusFilter) return false;
      if (productFilter && item.product !== productFilter) return false;

      return true;
    });
  }, [sales, search, statusFilter, productFilter]);

  /* ================= PAGINATION ================= */

  const itemsPerPage = 2;
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(filteredSales.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedSales = filteredSales.slice(
    startIndex,
    startIndex + itemsPerPage
  );

  /* ================= ACTIONS ================= */

  const handleAdd = (e) => {
    e.preventDefault();
    setSales([...sales, { id: Date.now(), ...formData }]);
    setFormData(emptyForm);
    setShowAdd(false);
  };

  const handleEdit = (e) => {
    e.preventDefault();
    setSales(
      sales.map((item) =>
        item.id === selectedItem.id ? selectedItem : item
      )
    );
    setShowEdit(false);
  };

  const handleDelete = () => {
    setSales(sales.filter((s) => s.id !== selectedItem.id));
    setShowDelete(false);
  };

  return (
    <div className="bg-white rounded-xl shadow p-5">

      {/* ================= HEADER ================= */}
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold">Recent Sales</h3>
        <button
          onClick={() => setShowAdd(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center gap-2"
        >
          <FaPlus /> Add
        </button>
      </div>

      {/* ================= SEARCH & FILTER BAR ================= */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-4 text-sm">
        <div className="flex items-center border rounded px-2">
          <FaSearch className="text-gray-400 mr-2" />
          <input
            placeholder="Search..."
            className="w-full py-1 outline-none"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        <select
          className="border px-2 py-1 rounded"
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="">All Status</option>
          <option>Pending</option>
          <option>Completed</option>
        </select>

        <select
          className="border px-2 py-1 rounded"
          value={productFilter}
          onChange={(e) => {
            setProductFilter(e.target.value);
            setCurrentPage(1);
          }}
        >
          <option value="">All Products</option>
          {[...new Set(sales.map((s) => s.product))].map((p) => (
            <option key={p}>{p}</option>
          ))}
        </select>
      </div>

      {/* ================= TABLE ================= */}
      <table className="w-full text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th className="p-3 text-left">Customer</th>
            <th className="text-left">Product</th>
            <th className="text-left">Amount</th>
            <th className="text-left">Status</th>
            <th className="text-center">Actions</th>
          </tr>
        </thead>

        <tbody>
          {paginatedSales.length === 0 ? (
            <tr>
              <td colSpan="5" className="text-center p-4 text-gray-500">
                No records found
              </td>
            </tr>
          ) : (
            paginatedSales.map((item) => (
              <tr key={item.id} className="border-t">
                <td className="p-3">{item.customer}</td>
                <td>{item.product}</td>
                <td>{item.amount}</td>
                <td>{item.status}</td>
                <td className="flex gap-2 justify-center py-2">
                  <button
                    onClick={() => {
                      setSelectedItem(item);
                      setShowView(true);
                    }}
                    className="bg-blue-500 text-white p-2 rounded"
                  >
                    <FaEye />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedItem({ ...item });
                      setShowEdit(true);
                    }}
                    className="bg-indigo-500 text-white p-2 rounded"
                  >
                    <FaEdit />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedItem(item);
                      setShowDelete(true);
                    }}
                    className="bg-red-500 text-white p-2 rounded"
                  >
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {/* ================= PAGINATION ================= */}
      <div className="flex justify-between items-center mt-4 text-sm">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((p) => p - 1)}
          className="flex items-center gap-2 px-3 py-1 bg-gray-100 rounded disabled:opacity-50"
        >
          <FaChevronLeft /> Previous
        </button>

        <span>
          Page {currentPage} of {totalPages || 1}
        </span>

        <button
          disabled={currentPage === totalPages || totalPages === 0}
          onClick={() => setCurrentPage((p) => p + 1)}
          className="flex items-center gap-2 px-3 py-1 bg-gray-100 rounded disabled:opacity-50"
        >
          Next <FaChevronRight />
        </button>
      </div>

      {/* ================= MODALS ================= */}
      {showAdd && (
        <Modal title="Add Sale" onClose={() => setShowAdd(false)}>
          <SaleForm data={formData} setData={setFormData} onSubmit={handleAdd} />
        </Modal>
      )}

      {showView && selectedItem && (
        <Modal title="Sale Details" onClose={() => setShowView(false)}>
          <p><b>Customer:</b> {selectedItem.customer}</p>
          <p><b>Product:</b> {selectedItem.product}</p>
          <p><b>Amount:</b> {selectedItem.amount}</p>
          <p><b>Status:</b> {selectedItem.status}</p>
        </Modal>
      )}

      {showEdit && selectedItem && (
        <Modal title="Edit Sale" onClose={() => setShowEdit(false)}>
          <SaleForm data={selectedItem} setData={setSelectedItem} onSubmit={handleEdit} />
        </Modal>
      )}

      {showDelete && (
        <Modal title="Are you sure?" onClose={() => setShowDelete(false)}>
          <p className="text-sm text-gray-500 mb-4">
            This action cannot be undone.
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={handleDelete}
              className="bg-red-600 text-white px-4 py-2 rounded"
            >
              Yes, Delete
            </button>
            <button
              onClick={() => setShowDelete(false)}
              className="bg-gray-200 px-4 py-2 rounded"
            >
              Cancel
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ================= REUSABLE ================= */

function Modal({ title, children, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
      <div className="bg-white w-full max-w-md rounded-xl p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4">
          <FaTimes />
        </button>
        <h3 className="font-semibold mb-4">{title}</h3>
        {children}
      </div>
    </div>
  );
}

function SaleForm({ data, setData, onSubmit }) {
  return (
    <form onSubmit={onSubmit} className="space-y-3 text-sm">
      <input
        className="w-full border px-3 py-2 rounded"
        placeholder="Customer Name"
        value={data.customer}
        onChange={(e) => setData({ ...data, customer: e.target.value })}
        required
      />
      <input
        className="w-full border px-3 py-2 rounded"
        placeholder="Product"
        value={data.product}
        onChange={(e) => setData({ ...data, product: e.target.value })}
        required
      />
      <input
        className="w-full border px-3 py-2 rounded"
        placeholder="Amount"
        value={data.amount}
        onChange={(e) => setData({ ...data, amount: e.target.value })}
        required
      />
      <select
        className="w-full border px-3 py-2 rounded"
        value={data.status}
        onChange={(e) => setData({ ...data, status: e.target.value })}
      >
        <option>Pending</option>
        <option>Completed</option>
      </select>
      <button className="w-full bg-indigo-600 text-white py-2 rounded-lg">
        Save
      </button>
    </form>
  );
}
