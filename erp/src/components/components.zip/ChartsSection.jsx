import { useMemo, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

/* ================= RAW DATA (same jaisa tumhara) ================= */
const rawMonthlySales = [
  { month: "Jan", year: 2025, amount: 40000 },
  { month: "Feb", year: 2025, amount: 52000 },
  { month: "Mar", year: 2025, amount: 48000 },
  { month: "Apr", year: 2025, amount: 61000 },
];

const rawInventoryData = [
  { name: "Laptops", count: 120, price: 55000 },
  { name: "Chairs", count: 80, price: 6500 },
];

export default function ChartsSection() {
  /* ================= FILTER STATE ================= */
  const [filters, setFilters] = useState({
    month: "",
    year: "",
    minPrice: "",
    maxPrice: "",
  });

  /* ================= FILTERED SALES DATA ================= */
  const filteredSales = useMemo(() => {
    return rawMonthlySales.filter((item) => {
      if (filters.month && item.month !== filters.month) return false;
      if (filters.year && item.year !== Number(filters.year)) return false;
      if (filters.minPrice && item.amount < Number(filters.minPrice))
        return false;
      if (filters.maxPrice && item.amount > Number(filters.maxPrice))
        return false;
      return true;
    });
  }, [filters]);

  /* ================= FILTERED INVENTORY DATA ================= */
  const filteredInventory = useMemo(() => {
    return rawInventoryData.filter((item) => {
      if (filters.minPrice && item.price < Number(filters.minPrice))
        return false;
      if (filters.maxPrice && item.price > Number(filters.maxPrice))
        return false;
      return true;
    });
  }, [filters]);

  return (
    <div className="space-y-6">

      {/* ================= FILTER BAR ================= */}
      <div className="bg-white rounded-xl shadow p-4">
        <h3 className="font-semibold mb-3">Chart Filters</h3>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
          {/* Month */}
          <select
            className="border px-2 py-1 rounded"
            value={filters.month}
            onChange={(e) =>
              setFilters({ ...filters, month: e.target.value })
            }
          >
            <option value="">All Months</option>
            <option>Jan</option>
            <option>Feb</option>
            <option>Mar</option>
            <option>Apr</option>
          </select>

          {/* Year */}
          <input
            type="number"
            placeholder="Year (e.g. 2025)"
            className="border px-2 py-1 rounded"
            value={filters.year}
            onChange={(e) =>
              setFilters({ ...filters, year: e.target.value })
            }
          />

          {/* Min Price */}
          <input
            type="number"
            placeholder="Min Amount"
            className="border px-2 py-1 rounded"
            value={filters.minPrice}
            onChange={(e) =>
              setFilters({ ...filters, minPrice: e.target.value })
            }
          />

          {/* Max Price */}
          <input
            type="number"
            placeholder="Max Amount"
            className="border px-2 py-1 rounded"
            value={filters.maxPrice}
            onChange={(e) =>
              setFilters({ ...filters, maxPrice: e.target.value })
            }
          />
        </div>
      </div>

      {/* ================= CHARTS ================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Monthly Sales Line Chart */}
        <div className="bg-white rounded-xl shadow p-5">
          <h3 className="font-semibold mb-4">Monthly Sales</h3>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={filteredSales}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="amount"
                stroke="#8B5CF6"
                strokeWidth={3}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Inventory Bar Chart */}
        <div className="bg-white rounded-xl shadow p-5">
          <h3 className="font-semibold mb-4">Inventory Status</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={filteredInventory}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#22C55E" />
            </BarChart>
          </ResponsiveContainer>
        </div>

      </div>
    </div>
  );
}
