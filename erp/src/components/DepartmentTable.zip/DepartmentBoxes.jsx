import {
  FaUsers,
  FaUserTie,
  FaUserGraduate,
  FaUserShield,
} from "react-icons/fa";

export default function DepartmentBoxes() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <Box title="Intern" icon={<FaUserGraduate />} color="bg-blue-500" />
      <Box title="HR" icon={<FaUsers />} color="bg-green-500" />
      <Box title="Senior Manager" icon={<FaUserTie />} color="bg-purple-500" />
      <Box title="Admin" icon={<FaUserShield />} color="bg-pink-500" />
    </div>
  );
}

function Box({ title, icon, color }) {
  return (
    <div
      className={`${color} text-white rounded-xl p-6 cursor-pointer hover:scale-105 transition`}
    >
      <div className="text-3xl mb-2">{icon}</div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="text-sm opacity-90">
        Click to manage {title}
      </p>
    </div>
  );
}
